package sae201;


public class SessionContext {
	//sert a transporter l'indice de la table
	public static int currentTableIndex;
	public static int tableSelectionner;

	public static Personne personneSelectionnerAAJouter = null;
	public static Groupe groupeSelectionnerAAJouter = null;

	public static Boolean deplacementEnCours = false;
}
