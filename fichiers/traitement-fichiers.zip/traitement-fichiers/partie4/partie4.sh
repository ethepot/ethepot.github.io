#!/bin/bash

bash tableau_part_medailles.sh
bash page_html.sh
bash html_to_pdf.sh
