#!/bin/bash

bash script_tableau.sh

bash script_drapeaux.sh